﻿using UnityEngine;
using System.Collections;

public class RepeatingBackground : MonoBehaviour
{

    private BoxCollider2D groundCollider;         //Collider attached to ground
    private float groundHorizontalLength;

    //Called before start
    private void Awake()
    {
        groundCollider = GetComponent<BoxCollider2D>();
        groundHorizontalLength = groundCollider.size.x;
    }

    //Runs once per frame
    private void Update()
    {
        //Difference between main camera and position of object 
        if (transform.position.x < -groundHorizontalLength)
        {
            RepositionBackground();
        }
    }

    //Create looping background effect
    private void RepositionBackground()
    {
        Vector2 groundOffSet = new Vector2(groundHorizontalLength * 2f, 0);
        transform.position = (Vector2)transform.position + groundOffSet;
    }
}