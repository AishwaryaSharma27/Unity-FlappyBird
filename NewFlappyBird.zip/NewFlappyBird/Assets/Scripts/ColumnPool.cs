﻿using UnityEngine;
using System.Collections;

public class ColumnPool : MonoBehaviour
{
    public GameObject columnPrefab;                 //column game object                                
    public int columnPoolSize = 5;                  // number of standby columns                              
    public float spawnRate = 3f;                    //column spawn rate

    //min and max y value of column position                                   
    public float columnMin = -1f;                                   
    public float columnMax = 3.5f;                                  

    private GameObject[] columns;                                   
    private int currentColumn = 0;                                  

    private Vector2 objectPoolPosition = new Vector2(-15, -25);      // unused columns
    private float spawnXPosition = 10f;

    private float timeSinceLastSpawned;


    void Start()
    {
        timeSinceLastSpawned = 0f;

        //Initialization
        columns = new GameObject[columnPoolSize];
        for (int i = 0; i < columnPoolSize; i++)
        {
            columns[i] = (GameObject)Instantiate(columnPrefab, objectPoolPosition, Quaternion.identity);
        }
    }

    //Spawn columns
    void Update()
    {
        timeSinceLastSpawned += Time.deltaTime;

        if (GameControl.instance.gameOver == false && timeSinceLastSpawned >= spawnRate)
        {
            timeSinceLastSpawned = 0f;
            
            float spawnYPosition = Random.Range(columnMin, columnMax);

            columns[currentColumn].transform.position = new Vector2(spawnXPosition, spawnYPosition);


            currentColumn++;

            if (currentColumn >= columnPoolSize)
            {
                currentColumn = 0;
            }
        }
    }
}