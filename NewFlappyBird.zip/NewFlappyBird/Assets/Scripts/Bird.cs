﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Bird : MonoBehaviour
{
    public float upForce = 200f;             //"flap" Upward force        
    private bool isDead = false;            

    private Animator anim;                  //Reference to the Animator component.
    private Rigidbody2D rb2d;               //Holds a reference to the Rigidbody2D component of the bird.

    void Start()
    {

        anim = GetComponent<Animator>();

        rb2d = GetComponent<Rigidbody2D>();
    }

    void Update()
    {

        if (isDead == false)
        {

            if (Input.GetKeyDown(KeyCode.Space))
            {
               
                anim.SetTrigger("Flap");
               
                rb2d.velocity = Vector2.zero;

                //give the bird some upward force
                rb2d.AddForce(new Vector2(0, upForce));
            }
        }
    }

    //Zero out bird's velocity if it collides
    void OnCollisionEnter2D(Collision2D other)
    {
       
        rb2d.velocity = Vector2.zero;
      
        isDead = true;
       
        anim.SetTrigger("Die");
    
        GameControl.instance.BirdDied();
    }

    //Bird goes beyond ceiling
    public void OnBecameInvisible()
    {
        rb2d.velocity = Vector2.zero;

        isDead = true;

        anim.SetTrigger("Die");
    }


}